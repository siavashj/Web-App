﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace WebAppTest4Siavash
{
    public partial class Page1 : System.Web.UI.Page
    {
        static string RefineText = "";
        static string strUserID = "";

        protected void CreateTableOfContent()
        {
            if(strUserID == null)
            {
                return;
            }
            SqlConnection mySqlConn = new SqlConnection();
            String cSqlServerUsername = "";
            String cSqlServerPassword = "";
            String cSqlServerName = "";
            String cSqlServerPort = "1433";
            String cSqlServerDatabaseName = "WebAppTest4Siavash";
            String mConnectionString = "Server=" + cSqlServerName + "," + cSqlServerPort + ";Database=" + cSqlServerDatabaseName + ";Uid=" + cSqlServerUsername + ";Pwd=" + cSqlServerPassword + ";Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;";
            mySqlConn.ConnectionString = mConnectionString;
            mySqlConn.Open();
            if (mySqlConn.State == System.Data.ConnectionState.Open)
            {
                string query = "";
                if (RefineText.Length == 0)
                {
                    query = "Select * From SampleData where fkUserId =" + strUserID;
                }
                else
                {
                    query = "Select * From SampleData where fkUserId =" + strUserID + " and Type Like '%" + RefineText + "%'";
                }                
                SqlCommand cmd = new SqlCommand(query, mySqlConn);
                SqlDataReader reader = cmd.ExecuteReader();
                string innerHTMLStr = "";
                int counter = 0;
                while (reader.Read())
                {
                    innerHTMLStr += "<tr>";
                    innerHTMLStr += "<th scope=\"row\">" + (counter+1).ToString() + "</th>";
                    innerHTMLStr += "<td>" + reader["Type"].ToString() + "</td>";
                    innerHTMLStr += "<td>" + reader["Value"].ToString() + "</td>";
                    innerHTMLStr += "</tr>";
                    ++counter;
                }
                NumOfRecords_DIV.InnerHtml = counter.ToString();
                TableBodyContent.InnerHtml = innerHTMLStr;
            }
            mySqlConn.Close();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Cookies["UserId"] == null)
            {
                Response.Redirect("default.aspx?msg=FalseAttemptToApproach");
            }
            strUserID = Request.Cookies["UserId"].Value.ToString();
            CreateTableOfContent();            
        }

        protected void SubmitBtn_Click(object sender, EventArgs e)
        {
            RefineText = FilterType_TextBox.Text;
            CreateTableOfContent();
        }

        
    }
}